# Furrmart Dog Food Finder

Static GitHub Pages website for Furrmart's Dog Food Finder.

## How to publish on GitHub Pages

1. Create a new GitHub repository.
   Suggested name: `furrmart-dog-food-finder`

2. Upload `index.html` to the repository.

3. Go to:
   Settings > Pages

4. Under "Build and deployment":
   - Source: Deploy from a branch
   - Branch: main
   - Folder: /root

5. Click Save.

6. GitHub will give you a free link like:
   https://yourusername.github.io/furrmart-dog-food-finder/

7. In Lightspeed custom code, embed it using:

<iframe 
  src="YOUR-GITHUB-PAGES-LINK-HERE" 
  style="width:100%;height:1100px;border:0;border-radius:20px;"
  loading="lazy">
</iframe>

